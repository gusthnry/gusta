//arrays são indexados
// possuem métodos
// poder ser iterados
const nome = "Luis";
const time = ["Pedrinho", "luizinho", "Jéfinho", "Cleitinho", "Robertinho"];
// (PARENTESES), [COLCHETES]. {CHAVES}
time.push("Zezinho"); // SEMPRE NO FINAL DA LISTA
time.shift(); // Remove alguem o início
console.log(time);
console.log(time[2]); // Cleitinho
console.log(time[20]); // undefined
time[20] = "Robertinho";
console.log(time[20]); // Robertinho
//ITERAR - LOOP ATÉ O ESGOTAMENTO (FOR, FOREACH, WHILE, FOR IN, FOR OF)
for (var i = 0; i <= 4; i++) {
  console.log(time[i]);
}
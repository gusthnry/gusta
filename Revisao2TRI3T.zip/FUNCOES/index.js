// FUNCOES
// DECLARAÇÃO
function diz0la() {
  console.log("Ola");
}
function olaPessoal(nome) {
  console.log(`Olá, ${nome}`);
}
const nome = "João";
const idade = 15;

function retornaDados() {
  return `Nome: ${nome} - Idade: ${idade}`;
}
// INVOCAÇÃO
// diz0la()
// olaPessoal('Tenório')
// console.log(retornaDados)

// FUNÇÕES PERSONALIZADAS VS FUNNÇÕES NATIVAS
setInterval(function () {
  console.log("Olá...");
}, 2000); // tempo ms
